var token = window.localStorage.getItem('token');

function getTms(){
        $.get("http://optometall.ru/api/v1/tms/region/?token="+token,
              function(tms, status){
              JSON.stringify(tms); //to string
              for(var i = 0; i < tms.length; i++){
              var data = tms[i].total_tms;
              var region = tms[i].region_id;
              document.getElementById("tms"+region).innerHTML = data;
              }
              });
}
function getLoans(){
    $.get("http://optometall.ru/api/v1/loans/region/?token="+token,
          function(loans, status){
          JSON.stringify(loans); //to string
          for(var i = 0; i < loans.length; i++){
          var data = loans[i].total;
          var region = loans[i].region_id;
          document.getElementById("dolg"+region).innerHTML = data;
          }
          });
}
function getSales(){
    $.get("http://optometall.ru/api/v1/elaman/vruchka/?token="+token,
          function(sales, status){
          JSON.stringify(sales); //to string
          for(var i = 0; i < sales.length; i++){
          var data = sales[i].total_sum;
          var region = sales[i].region_id;
          document.getElementById("vyr"+region).innerHTML = data;
          }
          });
}
function getKassa1(){
    $.get("http://optometall.ru/api/v1/kassa/region/1?token="+token,
          function(kassa, status){
          JSON.stringify(kassa); //to string
          var data;
          if(kassa){
          data = kassa.final_value;
          } else{
          data = 0;
          }
          document.getElementById("ostkassa1").innerHTML = data;
          
          });
}
function getKassa2(){
    $.get("http://optometall.ru/api/v1/kassa/region/2?token="+token,
          function(kassa, status){
          JSON.stringify(kassa); //to string
          var data;
          if(kassa){
          data = kassa.final_value;
          } else{
          data = 0;
          }
          document.getElementById("ostkassa2").innerHTML = data;
          });
}
function getKassa3(){
    $.get("http://optometall.ru/api/v1/kassa/region/3?token="+token,
          function(kassa, status){
          JSON.stringify(kassa); //to string
          var data;
          if(kassa){
          data = kassa.final_value;
          } else{
          data = 0;
          }
          document.getElementById("ostkassa3").innerHTML = data;
          });
}
function getKassa4(){
    $.get("http://optometall.ru/api/v1/kassa/region/4?token="+token,
          function(kassa, status){
          JSON.stringify(kassa); //to string
          var data;
          if(kassa){
          data = kassa.final_value;
          } else{
          data = 0;
          }
          document.getElementById("ostkassa4").innerHTML = data;
          });
}
function getRashod1(){
    $.get("http://optometall.ru/api/v1/expenses/total/1/?token="+token,
          function(expenses, status){
          JSON.stringify(expenses); //to string
          var data = expenses;
          document.getElementById("exp1").innerHTML = data;
          });
}
function getRashod2(){
    $.get("http://optometall.ru/api/v1/expenses/total/2/?token="+token,
          function(expenses, status){
          JSON.stringify(expenses); //to string
          var data = expenses;
          document.getElementById("exp2").innerHTML = data;
          });
}
function getRashod3(){
    $.get("http://optometall.ru/api/v1/expenses/total/3/?token="+token,
          function(expenses, status){
          JSON.stringify(expenses); //to string
          var data = expenses;
          document.getElementById("exp3").innerHTML = data;
          });
}
function getRashod4(){
    $.get("http://optometall.ru/api/v1/expenses/total/4/?token="+token,
          function(expenses, status){
          JSON.stringify(expenses); //to string
          var data = expenses;
          document.getElementById("exp4").innerHTML = data;
          });
}

function getProfit1(){
    $.get("http://optometall.ru/api/v1/profit/region/1/?token="+token,
          function(profit, status){
          JSON.stringify(profit); //to string
          var data = profit;
          document.getElementById("profit1").innerHTML = data;
          });
}
function getProfit2(){
    $.get("http://optometall.ru/api/v1/profit/region/2/?token="+token,
          function(profit, status){
          JSON.stringify(profit); //to string
          var data = profit;
          document.getElementById("profit2").innerHTML = data;
          });
}
function getProfit3(){
    $.get("http://optometall.ru/api/v1/profit/region/3/?token="+token,
          function(profit, status){
          JSON.stringify(profit); //to string
          var data = profit;
          document.getElementById("profit3").innerHTML = data;
          });
}
function getProfit4(){
    $.get("http://optometall.ru/api/v1/profit/region/4/?token="+token,
          function(profit, status){
          JSON.stringify(profit); //to string
          var data = profit;
          document.getElementById("profit4").innerHTML = data;
          });
}


var app = {
    // Application Constructor
initialize: function() {
    this.bindEvents();
},
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
bindEvents: function() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
},
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
onDeviceReady: function() {
    app.receivedEvent('deviceready');
    getTms();
    getRashod1();
    getRashod2();
    getRashod3();
    getRashod4();
    getProfit1();
    getProfit2();
    getProfit3();
    getProfit4();
    getKassa1();
    getKassa2();
    getKassa3();
    getKassa4();
    getLoans();
    getSales();
    
    
},
    // Update DOM on a Received Event
receivedEvent: function(id) {
}
    
};


