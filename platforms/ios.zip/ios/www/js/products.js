


/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

function getProducts() {
    $.get("http://optometall.ru/api/v1/product/region/"+regionid+"?token="+window.localStorage.getItem('token'), function(productcat, status){
          JSON.stringify(productcat); //to string
          var data = "";
          for (i = 0; i < productcat.length; i++) {
          data += '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">';
          data += '<a data-toggle="collapse" href="#'+productcat[i].name+'">';
          data += productcat[i].name;
          data += '</a>';
          data += '</h4></div>';
          data += '<div id="'+productcat[i].name+'" class="panel-collapse collapse">';
          data += '<table class="table table-striped table-hover table-bordered" id="sample_editable_1">';
          data += '<thead><tr><th style="width:100px"> Наименование </th><th> Ед. Изм. </th> <th> Остаток </th> <th> Прайс. цена </th> </tr></thead>';
          data += '<tbody>';
          for (j = 0; j < productcat[i].products.length; j++) {
          data += '<tr class="odd gradeX package-row">';
          data += '<td class="center">';
          data += productcat[i].products[j].product_name;
          data += '</td>';
          data += '<td>';
          data += productcat[i].products[j].msb;
          data += '</td>';
          data += '<td>';
          data += productcat[i].products[j].quantity;
          data += '</td>';
          data += '<td>';
          data += productcat[i].products[j].price;
          data += '</td>';
          data += '</tr>';
          }
          data +=  '</tbody>';
          data += '</table>';
          data += '</div></div>';
          }
          var twitter = document.getElementById("productstable");
          twitter.innerHTML = data;
          });
}
var app = {
    // Application Constructor
initialize: function() {
    this.bindEvents();
},
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
bindEvents: function() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
},
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
onDeviceReady: function() {
    app.receivedEvent('deviceready');
    getProducts(location.search.substring(1));
    var username = window.localStorage.getItem('user_name');
    document.getElementById("username").innerHTML = username;
},
    // Update DOM on a Received Event
receivedEvent: function(id) {
}
    
};
