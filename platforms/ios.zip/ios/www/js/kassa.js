
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

function getKassa(regionid){
    $.get("http://optometall.ru/api/v1/kassa/current/"+regionid+"?token="+window.localStorage.getItem('token'), function(cases, status){
          JSON.stringify(cases); //to string
          var data = "";
          data += '<table class="table table-striped table-hover table-bordered" id="sample_editable_1">';
          data += '<thead><tr><th> Дата </th><th> Начальная сумма </th> <th> Окончательная сумма </th> <th> Разница </th>  <th> Тип </th></tr></thead>';
          data += '<tbody>';
          for (j = 0; j < cases.length; j++) {
          data += '<tr class="odd gradeX package-row">';
          data += '<td class="center">';
          data += cases[j].created_at;
          data += '</td>';
          data += '<td>';
          data += cases[j].initial_value;
          data += '</td>';
          data += '<td>';
          data += cases[j].final_value;
          data += '</td>';
          data += '<td>';
          data += cases[j].final_value - cases[j].initial_value;
          data += '</td>';
          data += '<td>';
          data += cases[j].action_type;
          data += '</td>';
          data += '</tr>';
          }
          data +=  '</tbody>';
          data += '</table>';
          
          var twitter = document.getElementById("kassatable");
          twitter.innerHTML = data;
          });
}



var app = {
    // Application Constructor
initialize: function() {
    this.bindEvents();
},
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
bindEvents: function() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
},
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
onDeviceReady: function() {
    app.receivedEvent('deviceready');
    getKassa(location.search.substring(1));
    var username = window.localStorage.getItem('user_name');
    document.getElementById("username1").innerHTML = username;
},
    // Update DOM on a Received Event
receivedEvent: function(id) {
}
    
};
