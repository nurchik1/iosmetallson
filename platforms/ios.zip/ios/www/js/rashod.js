


/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

function getExpanse(regionid){
    $.get("http://optometall.ru/api/v1/expense/region/"+regionid+"?token="+window.localStorage.getItem('token'), function(expenses, status){
          JSON.stringify(expenses); //to string
          var data = "";
          data += '<table class="table table-striped table-hover table-bordered" id="sample_editable_1">';
          data += '<thead><tr><th> Дата </th><th>Сумма</th> <th> Кому </th> <th> Кассир </th>  <th> Категория </th><th>Коммент</th></tr></thead>';
          data += '<tbody>';
          for (i = 0; i < expenses.length; i++) {
          data += '<tr class="odd gradeX package-row">';
          data += '<td class="center">';
          data += expenses[i].created_at;
          data += '</td>';
          data += '<td>';
          data += expenses[i].amount;
          data += '</td>';
          data += '<td>';
          data += expenses[i].expense_name;
          data += '</td>';
          data += '<td>';
          data += expenses[i].user.name;
          data += '</td>';
          data += '<td>';
          data += expenses[i].category.name;
          data += '</td>';
          data += '<td>';
          data += expenses[i].notes;
          data += '</td>';
          data += '</tr>';
          
          }
          data +=  '</tbody>';
          data += '</table>';
          
          var twitter = document.getElementById("expansetable");
          twitter.innerHTML = data;
          });
}
var app = {
    // Application Constructor
initialize: function() {
    this.bindEvents();
},
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
bindEvents: function() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
},
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
onDeviceReady: function() {
    app.receivedEvent('deviceready');
    getExpanse(location.search.substring(1));
    var username = window.localStorage.getItem('user_name');
    document.getElementById("username").innerHTML = username;
},
    // Update DOM on a Received Event
receivedEvent: function(id) {
}
    
};
